import React, { useEffect, useState } from 'react';
import { Container, Typography, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, Paper, CircularProgress, Button } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { api } from '../api';

export default function OrdersPage() {
    const { t } = useTranslation();
    const [orders, setOrders]   = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        api.get('/orders')
            .then(r => setOrders(r.data))
            .catch(console.error)
            .finally(() => setLoading(false));
    }, []);

    if (loading) {
        return <CircularProgress sx={{ display:'block', mx:'auto', mt:4 }} />;
    }

    return (
        <Container sx={{ py:4 }}>
            <Typography variant="h4" gutterBottom>
                {t('ordersPage.title')}
            </Typography>
            <TableContainer component={Paper}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>{t('ordersPage.header.id')}</TableCell>
                            <TableCell>{t('ordersPage.header.type')}</TableCell>
                            <TableCell>{t('ordersPage.header.state')}</TableCell>
                            <TableCell>{t('ordersPage.header.deliveryCost')}</TableCell>
                            <TableCell>{t('ordersPage.header.action')}</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {orders.map(o => (
                            <TableRow key={o.id} hover>
                                <TableCell>{o.id}</TableCell>
                                <TableCell>{o.type}</TableCell>
                                <TableCell>{o.state}</TableCell>
                                <TableCell>{o.deliveryCost}</TableCell>
                                <TableCell>
                                    <Button size="small" component={RouterLink} to={`/orders/${o.id}`}>
                                        {t('ordersPage.view')}
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </Container>
    );
}
