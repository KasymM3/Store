import React, { useState, useEffect, useCallback } from 'react';
import {
    Container, Typography, Box, Button,
    TableContainer, Table, TableHead, TableRow, TableCell, TableBody,
    Paper, IconButton, CircularProgress
} from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon   from '@mui/icons-material/Edit';
import { api } from '../api';
import { useTranslation } from 'react-i18next';

export default function AdminPage() {
    const { t } = useTranslation();
    const [products, setProducts] = useState([]);
    const [loading, setLoading]   = useState(true);
    const [error, setError]       = useState(null);

    const fetchProducts = useCallback(() => {
        setLoading(true);
        setError(null);
        api.get('/products')
            .then(res => setProducts(res.data))
            .catch(() => setError(t('adminPage.loadError')))
            .finally(() => setLoading(false));
    }, [t]);

    useEffect(() => { fetchProducts(); }, [fetchProducts]);

    const handleDelete = id => {
        if (!window.confirm(t('adminPage.deleteConfirm'))) return;
        api.delete(`/products/${id}`)
            .then(() => setProducts(prev => prev.filter(p => p.id !== id)))
            .catch(() => alert(t('adminPage.deleteError')));
    };

    return (
        <Container sx={{ py:4 }}>
            <Typography variant="h4" gutterBottom>
                {t('adminPage.title')}
            </Typography>
            <Box sx={{ display:'flex', gap:2, mb:4, flexWrap:'wrap' }}>
                <Button variant="contained" color="success" component={RouterLink} to="/products/new">
                    {t('adminPage.addNew')}
                </Button>
                <Button variant="outlined" component={RouterLink} to="/products">
                    {t('adminPage.backToCatalog')}
                </Button>
            </Box>

            {loading && <CircularProgress />}
            {error   && <Typography color="error">{error}</Typography>}

            {!loading && !error && (
                <TableContainer component={Paper}>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell>{t('adminPage.header.id')}</TableCell>
                                <TableCell>{t('adminPage.header.name')}</TableCell>
                                <TableCell>{t('adminPage.header.price')}</TableCell>
                                <TableCell>{t('adminPage.header.category')}</TableCell>
                                <TableCell>{t('adminPage.header.actions')}</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {products.map(p => (
                                <TableRow key={p.id} hover>
                                    <TableCell>{p.id}</TableCell>
                                    <TableCell>{p.name}</TableCell>
                                    <TableCell>{p.price}</TableCell>
                                    <TableCell>{p.category?.name || '—'}</TableCell>
                                    <TableCell>
                                        <IconButton component={RouterLink} to={`/products/${p.id}/edit`} color="primary">
                                            <EditIcon />
                                        </IconButton>
                                        <IconButton onClick={() => handleDelete(p.id)} color="error">
                                            <DeleteIcon />
                                        </IconButton>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            )}
        </Container>
    );
}
