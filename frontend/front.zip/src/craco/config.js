// craco.config.js
const path = require('path');

module.exports = {
    babel: {
        plugins: [
            '@babel/plugin-proposal-optional-chaining',
            '@babel/plugin-proposal-nullish-coalescing-operator'
        ]
    },
    webpack: {
        configure: (webpackConfig) => {
            // найдем правило babel-loader и расширим include, чтобы обработать MUI
            const oneOf = webpackConfig.module.rules.find(r => Array.isArray(r.oneOf)).oneOf;
            const babelRule = oneOf.find(r => r.loader && r.loader.includes('babel-loader'));
            if (babelRule && babelRule.include) {
                babelRule.include = Array.isArray(babelRule.include)
                    ? [...babelRule.include, path.resolve(__dirname, 'node_modules/@mui/system')]
                    : [babelRule.include, path.resolve(__dirname, 'node_modules/@mui/system')];
            }
            return webpackConfig;
        }
    }
};
