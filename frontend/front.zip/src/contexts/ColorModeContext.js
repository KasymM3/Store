import React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import CssBaseline from '@mui/material/CssBaseline';

export const ColorModeContext = React.createContext({
    mode: 'light',
    toggleColorMode: () => {},
});

export default function ColorModeProvider({ children }) {
    // Сначала пытаемся угадать из системных настроек
    const prefersDarkMode = useMediaQuery('(prefers-color-scheme: dark)');

    const [mode, setMode] = React.useState(prefersDarkMode ? 'dark' : 'light');

    const colorMode = React.useMemo(
        () => ({
            mode,
            toggleColorMode: () => {
                setMode(prev => (prev === 'light' ? 'dark' : 'light'));
            },
        }),
        [mode],
    );

    // Собираем тему MUI с текущим mode
    const theme = React.useMemo(
        () =>
            createTheme({
                palette: { mode },
                typography: {
                    button: { textTransform: 'none' },
                },
            }),
        [mode],
    );

    return (
        <ColorModeContext.Provider value={colorMode}>
            <ThemeProvider theme={theme}>
                <CssBaseline />
                {children}
            </ThemeProvider>
        </ColorModeContext.Provider>
    );
}
