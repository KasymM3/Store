import React, { useContext } from 'react';
import { Container, Typography, Box, Button } from '@mui/material';
import { AuthContext } from '../contexts/AuthContext';
import { Link as RouterLink } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export default function HomePage() {
    const { t } = useTranslation();
    const { logout, userRoles } = useContext(AuthContext);

    return (
        <Container sx={{ py: 4 }}>
            <Typography variant="h2" gutterBottom>
                {t('homePage.welcome')}
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, gap: 2 }}>
                <Button variant="outlined" onClick={logout}>
                    {t('homePage.logout')}
                </Button>
                {userRoles.includes('ROLE_ADMIN') && (
                    <Button variant="contained" component={RouterLink} to="/admin">
                        {t('homePage.adminPanel')}
                    </Button>
                )}
            </Box>
        </Container>
    );
}
