import React, { useState, useEffect } from 'react';
import { Container, Card, CardHeader, CardContent, List, ListItem, ListItemText, Button, Box, CircularProgress, Typography } from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { api } from '../api';

export default function OrderDetailPage() {
    const { t } = useTranslation();
    const { id } = useParams();
    const navigate = useNavigate();
    const [order, setOrder] = useState(null);

    useEffect(() => {
        api.get(`/orders/${id}`)
            .then(r => setOrder(r.data))
            .catch(console.error);
    }, [id]);

    if (!order) {
        return <Box textAlign="center" py={4}><CircularProgress /></Box>;
    }

    const handleAction = async action => {
        const params = new URLSearchParams({ action });
        try {
            const res = await fetch(`/api/orders/${id}/action`, {
                method: 'POST',
                headers: {'Content-Type':'application/x-www-form-urlencoded'},
                body: params.toString()
            });
            if (!res.ok) throw new Error(`Error ${res.status}`);
            const msgKey = action === 'pay' ? 'paid' : action === 'cancel' ? 'cancelled' : 'refunded';
            alert(t(`orderDetailPage.alerts.${msgKey}`));
            navigate('/orders');
        } catch (e) {
            alert(t('orderDetailPage.alerts.error', { message: e.message }));
        }
    };

    const state = order.state.toLowerCase();
    const isNew = state.startsWith('new');
    const isClosed = state.startsWith('closed');

    return (
        <Container maxWidth="sm" sx={{ py:4 }}>
            <Card>
                <CardHeader title={t('orderDetailPage.orderNumber', { id: order.id })} />
                <CardContent>
                    <List>
                        <ListItem><ListItemText primary={`${t('orderDetailPage.type')}: ${order.type}`} /></ListItem>
                        <ListItem><ListItemText primary={`${t('orderDetailPage.state')}: ${order.state}`} /></ListItem>
                        <ListItem><ListItemText primary={`${t('orderDetailPage.basePrice')}: $${order.basePrice}`} /></ListItem>
                        <ListItem><ListItemText primary={`${t('orderDetailPage.deliveryCost')}: $${order.deliveryCost}`} /></ListItem>
                        <ListItem><ListItemText primary={`${t('orderDetailPage.total')}: $${order.basePrice + order.deliveryCost}`} /></ListItem>
                        <ListItem><ListItemText primary={`${t('orderDetailPage.estimatedDays')}: ${order.estimatedDays}`} /></ListItem>
                    </List>

                    <Box sx={{ display:'flex', gap:2, mt:2 }}>
                        {isNew && (
                            <>
                                <Button variant="contained" color="success" fullWidth onClick={() => handleAction('pay')}>
                                    {t('orderDetailPage.actions.pay')}
                                </Button>
                                <Button variant="outlined" color="warning" fullWidth onClick={() => handleAction('cancel')}>
                                    {t('orderDetailPage.actions.cancel')}
                                </Button>
                            </>
                        )}
                        {isClosed && (
                            <Button variant="contained" color="error" fullWidth onClick={() => handleAction('refund')}>
                                {t('orderDetailPage.actions.refund')}
                            </Button>
                        )}
                    </Box>
                </CardContent>
                <Box sx={{ textAlign:'right', p:2 }}>
                    <Button onClick={() => navigate('/orders')}>
                        {t('orderDetailPage.backToList')}
                    </Button>
                </Box>
            </Card>
        </Container>
    );
}
