import React, { useEffect, useState } from 'react';
import { Container, Typography, Grid, Card, CardContent, CardActions, Button, Box, CircularProgress } from '@mui/material';
import { api } from '../api';
import { useTranslation } from 'react-i18next';

export default function CartPage() {
    const { t } = useTranslation();
    const [cart, setCart] = useState(null);

    useEffect(() => {
        api.get('/cart')
            .then(r => setCart(r.data))
            .catch(err => { console.error(err); setCart([]); });
    }, []);

    const orderItem = productId => {
        api.post(`/cart/order/${productId}`)
            .then(() => setCart(prev => prev.filter(i => i.productId !== productId)))
            .catch(console.error);
    };

    const checkoutAll = () => {
        api.post('/cart/checkout')
            .then(() => setCart([]))
            .catch(console.error);
    };

    if (cart === null) {
        return <Box textAlign="center" py={4}><CircularProgress /></Box>;
    }

    return (
        <Container sx={{ py: 4 }}>
            <Typography variant="h4" gutterBottom>
                {t('cartPage.title')}
            </Typography>
            {cart.length === 0 ? (
                <Typography>{t('cartPage.empty')}</Typography>
            ) : (
                <>
                    <Grid container spacing={4}>
                        {cart.map(item => (
                            <Grid item xs={12} sm={6} md={4} lg={3} key={item.productId}>
                                <Card sx={{ display:'flex', flexDirection:'column', height:'100%' }}>
                                    <CardContent sx={{ flexGrow:1 }}>
                                        <Typography variant="h6">{item.name}</Typography>
                                        <Typography variant="body2" color="text.secondary">{item.category}</Typography>
                                        <Typography variant="subtitle1" mt={2}>${item.price}</Typography>
                                    </CardContent>
                                    <CardActions>
                                        <Button fullWidth variant="contained" onClick={() => orderItem(item.productId)}>
                                            {t('cartPage.order')}
                                        </Button>
                                    </CardActions>
                                </Card>
                            </Grid>
                        ))}
                    </Grid>
                    <Box textAlign="center" mt={4}>
                        <Button variant="contained" onClick={checkoutAll}>
                            {t('cartPage.checkoutAll')}
                        </Button>
                    </Box>
                </>
            )}
        </Container>
    );
}
