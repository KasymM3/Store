import React, { useState } from 'react';
import { Container, Card, CardHeader, CardContent, TextField, MenuItem, Button, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export default function OrderFormPage() {
    const { t } = useTranslation();
    const [type, setType]   = useState('physical');
    const [price, setPrice] = useState('');
    const navigate          = useNavigate();

    const handleSubmit = async e => {
        e.preventDefault();
        await fetch('/api/orders', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ type, basePrice: parseFloat(price) })
        });
        navigate('/orders');
    };

    return (
        <Container maxWidth="sm" sx={{ py: 4 }}>
            <Card>
                <CardHeader title={t('orderFormPage.title')} />
                <CardContent>
                    <Box component="form" onSubmit={handleSubmit} sx={{ display:'flex', flexDirection:'column', gap:2 }}>
                        <TextField
                            select
                            label={t('orderFormPage.typeLabel')}
                            value={type}
                            onChange={e => setType(e.target.value)}
                            required
                        >
                            <MenuItem value="physical">{t('orderFormPage.type.physical')}</MenuItem>
                            <MenuItem value="digital">{t('orderFormPage.type.digital')}</MenuItem>
                        </TextField>
                        <TextField
                            label={t('orderFormPage.priceLabel')}
                            type="number"
                            inputProps={{ step:'0.01' }}
                            value={price}
                            onChange={e => setPrice(e.target.value)}
                            required
                        />
                        <Box sx={{ display:'flex', gap:2, justifyContent:'flex-end' }}>
                            <Button type="submit" variant="contained">{t('orderFormPage.create')}</Button>
                            <Button variant="outlined" onClick={() => navigate('/orders')}>
                                {t('orderFormPage.cancel')}
                            </Button>
                        </Box>
                    </Box>
                </CardContent>
            </Card>
        </Container>
    );
}
