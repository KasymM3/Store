import React from 'react';
import {
    AppBar,
    Toolbar,
    IconButton,
    Typography,
    Button,
    Box,
    Drawer,
    List,
    ListItem,
    ListItemButton,
    Menu,
    MenuItem,
    Tooltip,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import Brightness4Icon from '@mui/icons-material/Brightness4';
import Brightness7Icon from '@mui/icons-material/Brightness7';
import TranslateIcon from '@mui/icons-material/Translate';
import { Link as RouterLink } from 'react-router-dom';
import { useTheme } from '@mui/material/styles';
import { useTranslation } from 'react-i18next';
import { ColorModeContext } from '../contexts/ColorModeContext';

export default function NavBar() {
    const theme = useTheme();
    const colorMode = React.useContext(ColorModeContext);
    const { t, i18n } = useTranslation();

    const [drawerOpen, setDrawerOpen] = React.useState(false);
    const [langAnchor, setLangAnchor] = React.useState(null);

    const handleDrawerToggle = () => {
        setDrawerOpen(!drawerOpen);
    };

    const handleLangClick = (event) => {
        setLangAnchor(event.currentTarget);
    };
    const handleLangClose = () => {
        setLangAnchor(null);
    };
    const handleChangeLanguage = (lng) => {
        i18n.changeLanguage(lng);
        handleLangClose();
    };

    // Навигационные пункты
    const pages = [
        { label: t('nav.home'),     path: '/'         },
        { label: t('nav.products'), path: '/products' },
        { label: t('nav.cart'),     path: '/cart'     },
        { label: t('nav.orders'),   path: '/orders'   },
    ];

    const drawer = (
        <Box onClick={handleDrawerToggle} sx={{ width: 240 }}>
            <List>
                {pages.map((p) => (
                    <ListItem key={p.path} disablePadding>
                        <ListItemButton component={RouterLink} to={p.path}>
                            {p.label}
                        </ListItemButton>
                    </ListItem>
                ))}
            </List>
        </Box>
    );

    return (
        <>
            <AppBar position="sticky">
                <Toolbar>
                    {/* Кнопка открытия бокового меню на мобильных */}
                    <IconButton
                        edge="start"
                        color="inherit"
                        aria-label="menu"
                        onClick={handleDrawerToggle}
                        sx={{ mr: 2, display: { sm: 'none' } }}
                    >
                        <MenuIcon />
                    </IconButton>

                    {/* Логотип / название */}
                    <Typography
                        variant="h6"
                        component={RouterLink}
                        to="/"
                        sx={{
                            color: 'inherit',
                            textDecoration: 'none',
                            flexGrow: 1,
                        }}
                    >
                        ShopApp
                    </Typography>

                    {/* Кнопки навигации для desktop */}
                    <Box sx={{ display: { xs: 'none', sm: 'flex' }, gap: 1 }}>
                        {pages.map((p) => (
                            <Button
                                key={p.path}
                                component={RouterLink}
                                to={p.path}
                                color="inherit"
                                sx={{ textTransform: 'none' }}
                            >
                                {p.label}
                            </Button>
                        ))}
                    </Box>

                    {/* Переключатель темы */}
                    <Tooltip title={t('nav.toggleTheme')}>
                        <IconButton
                            sx={{ ml: 1 }}
                            onClick={colorMode.toggleColorMode}
                            color="inherit"
                        >
                            {theme.palette.mode === 'dark' ? (
                                <Brightness7Icon />
                            ) : (
                                <Brightness4Icon />
                            )}
                        </IconButton>
                    </Tooltip>

                    {/* Выбор языка */}
                    <Tooltip title={t('nav.changeLanguage')}>
                        <IconButton
                            onClick={handleLangClick}
                            color="inherit"
                            sx={{ ml: 1 }}
                        >
                            <TranslateIcon />
                        </IconButton>
                    </Tooltip>
                    <Menu
                        anchorEl={langAnchor}
                        open={Boolean(langAnchor)}
                        onClose={handleLangClose}
                    >
                        <MenuItem onClick={() => handleChangeLanguage('en')}>
                            English
                        </MenuItem>
                        <MenuItem onClick={() => handleChangeLanguage('ru')}>
                            Русский
                        </MenuItem>
                    </Menu>
                </Toolbar>
            </AppBar>

            {/* Боковая панель на мобильных */}
            <Drawer
                anchor="left"
                open={drawerOpen}
                onClose={handleDrawerToggle}
                ModalProps={{ keepMounted: true }}
                sx={{
                    display: { xs: 'block', sm: 'none' },
                    '& .MuiDrawer-paper': { boxSizing: 'border-box', width: 240 },
                }}
            >
                {drawer}
            </Drawer>
        </>
    );
}
