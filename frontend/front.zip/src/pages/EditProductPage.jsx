import React, { useState, useEffect } from 'react';
import { Container, Card, CardHeader, CardContent, TextField, MenuItem, Button, Box, CircularProgress, Typography } from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../api';
import { useTranslation } from 'react-i18next';

export default function EditProductPage() {
    const { t }     = useTranslation();
    const { id }    = useParams();
    const navigate  = useNavigate();
    const [loading, setLoading] = useState(true);
    const [error, setError]     = useState(null);
    const [product, setProduct] = useState({
        name:'', description:'', price:'', imageUrl:'', category:''
    });
    const [categories] = useState(['Digital','Physical']);

    useEffect(() => {
        api.get(`/products/${id}`)
            .then(r => setProduct(r.data))
            .catch(() => setError(t('editProductPage.loadError')))
            .finally(() => setLoading(false));
    }, [id, t]);

    const handleChange = e => {
        const { name, value } = e.target;
        setProduct(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async e => {
        e.preventDefault();
        try {
            await api.put(`/products/${id}`, product);
            navigate('/admin', { replace: true });
        } catch (err) {
            alert(t('editProductPage.saveError', { message: err.response?.data || err.message }));
        }
    };

    if (loading) {
        return <Box textAlign="center" py={4}><CircularProgress /></Box>;
    }
    if (error) {
        return <Typography color="error" align="center" py={4}>{error}</Typography>;
    }

    return (
        <Container maxWidth="sm" sx={{ py: 4 }}>
            <Card>
                <CardHeader title={t('editProductPage.title', { id })} />
                <CardContent>
                    <Box component="form" onSubmit={handleSubmit} sx={{ display:'flex', flexDirection:'column', gap:2 }}>
                        <TextField
                            label={t('editProductPage.nameLabel')}
                            name="name"
                            value={product.name}
                            onChange={handleChange}
                            required fullWidth
                        />
                        <TextField
                            label={t('editProductPage.descriptionLabel')}
                            name="description"
                            value={product.description}
                            onChange={handleChange}
                            multiline rows={3}
                            fullWidth
                        />
                        <TextField
                            label={t('editProductPage.priceLabel')}
                            name="price"
                            type="number"
                            inputProps={{ step: "0.01" }}
                            value={product.price}
                            onChange={handleChange}
                            required fullWidth
                        />
                        <TextField
                            label={t('editProductPage.imageUrlLabel')}
                            name="imageUrl"
                            value={product.imageUrl}
                            onChange={handleChange}
                            fullWidth
                        />
                        <TextField
                            select
                            label={t('editProductPage.categoryLabel')}
                            name="category"
                            value={product.category}
                            onChange={handleChange}
                            required fullWidth
                        >
                            <MenuItem value="">{t('editProductPage.categoryPlaceholder')}</MenuItem>
                            {categories.map(c => (
                                <MenuItem key={c} value={c}>{c}</MenuItem>
                            ))}
                        </TextField>
                        <Box sx={{ display:'flex', gap:2, justifyContent:'flex-end' }}>
                            <Button variant="contained" color="success" type="submit">
                                {t('editProductPage.save')}
                            </Button>
                            <Button variant="outlined" onClick={() => navigate('/admin')}>
                                {t('editProductPage.cancel')}
                            </Button>
                        </Box>
                    </Box>
                </CardContent>
            </Card>
        </Container>
    );
}
