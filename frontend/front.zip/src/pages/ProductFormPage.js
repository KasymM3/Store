import React, { useState, useEffect } from 'react';
import { Container, Card, CardHeader, CardContent, TextField, MenuItem, Button, Box } from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../api';
import { useTranslation } from 'react-i18next';

export default function ProductFormPage() {
    const { t }     = useTranslation();
    const { id }    = useParams();
    const navigate  = useNavigate();
    const [product, setProduct] = useState({
        name: '', description: '', price: '', imageUrl: '', category: ''
    });
    const [categories] = useState(['Digital','Physical']);

    useEffect(() => {
        if (id) {
            api.get(`/products/${id}`).then(r => setProduct(r.data)).catch(console.error);
        }
    }, [id]);

    const handleChange = e => {
        const { name, value } = e.target;
        setProduct(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async e => {
        e.preventDefault();
        try {
            if (id) await api.put(`/products/${id}`, product);
            else     await api.post('/products', product);
            navigate('/products');
        } catch (err) {
            alert(t('productFormPage.saveError', { message: err.response?.data || err.message }));
        }
    };

    return (
        <Container maxWidth="sm" sx={{ py: 4 }}>
            <Card>
                <CardHeader title={id ? t('productFormPage.editTitle') : t('productFormPage.addTitle')} />
                <CardContent>
                    <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                        <TextField
                            label={t('productFormPage.nameLabel')}
                            name="name"
                            value={product.name}
                            onChange={handleChange}
                            required fullWidth
                        />
                        <TextField
                            label={t('productFormPage.descriptionLabel')}
                            name="description"
                            value={product.description}
                            onChange={handleChange}
                            multiline rows={3}
                            fullWidth
                        />
                        <TextField
                            label={t('productFormPage.priceLabel')}
                            name="price"
                            type="number"
                            inputProps={{ step: "0.01" }}
                            value={product.price}
                            onChange={handleChange}
                            required fullWidth
                        />
                        <TextField
                            label={t('productFormPage.imageUrlLabel')}
                            name="imageUrl"
                            value={product.imageUrl}
                            onChange={handleChange}
                            fullWidth
                        />
                        <TextField
                            select
                            label={t('productFormPage.categoryLabel')}
                            name="category"
                            value={product.category}
                            onChange={handleChange}
                            required fullWidth
                        >
                            <MenuItem value="">{t('productFormPage.categoryPlaceholder')}</MenuItem>
                            {categories.map(c => (
                                <MenuItem key={c} value={c}>{c}</MenuItem>
                            ))}
                        </TextField>
                        <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
                            <Button variant="contained" color="success" type="submit">
                                {t('productFormPage.save')}
                            </Button>
                            <Button variant="outlined" onClick={() => navigate('/products')}>
                                {t('productFormPage.cancel')}
                            </Button>
                        </Box>
                    </Box>
                </CardContent>
            </Card>
        </Container>
    );
}
