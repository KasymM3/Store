import React, { useState, useContext } from 'react';
import { Container, Card, CardHeader, CardContent, TextField, Button, Typography, Link, Box } from '@mui/material';
import { AuthContext } from '../contexts/AuthContext';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export default function LoginPage() {
    const { t } = useTranslation();
    const { login } = useContext(AuthContext);
    const navigate = useNavigate();
    const [email, setEmail]       = useState('');
    const [password, setPassword] = useState('');
    const [error, setError]       = useState('');

    const handleSubmit = async e => {
        e.preventDefault();
        try {
            await login(email, password);
            navigate('/');
        } catch (err) {
            setError(err.response?.data || err.message || t('loginPage.loginFailed'));
        }
    };

    return (
        <Container maxWidth="sm" sx={{ py: 4 }}>
            <Card>
                <CardHeader title={t('loginPage.title')} />
                <CardContent>
                    <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                        <TextField
                            label={t('loginPage.emailPlaceholder')}
                            type="email"
                            value={email}
                            onChange={e => setEmail(e.target.value)}
                            required
                            fullWidth
                        />
                        <TextField
                            label={t('loginPage.passwordPlaceholder')}
                            type="password"
                            value={password}
                            onChange={e => setPassword(e.target.value)}
                            required
                            fullWidth
                        />
                        <Button type="submit" variant="contained">
                            {t('loginPage.login')}
                        </Button>
                        {error && <Typography color="error">{error}</Typography>}
                        <Typography variant="body2">
                            {t('loginPage.noAccount')}{' '}
                            <Link component={RouterLink} to="/register">
                                {t('loginPage.register')}
                            </Link>
                        </Typography>
                        <Typography variant="body2">
                            <Link component={RouterLink} to="/reset-password">
                                {t('loginPage.forgotPassword')}
                            </Link>
                        </Typography>
                    </Box>
                </CardContent>
            </Card>
        </Container>
    );
}
