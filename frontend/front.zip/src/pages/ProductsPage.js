import React, { useEffect, useContext } from 'react';
import {
    Container, Grid, Card, CardMedia, CardContent, Typography, CardActions, Button, TextField, MenuItem, Box, CircularProgress
} from '@mui/material';
import { Link as RouterLink, useSearchParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { AuthContext } from '../contexts/AuthContext';
import { useSelector, useDispatch } from 'react-redux';
import { fetchProducts } from '../store/productsSlice';
import { fetchLikes, toggleLike } from '../store/likesSlice';
import { fetchCart, addToCart } from '../store/cartSlice';

export default function ProductsPage() {
    const { t }       = useTranslation();
    const { userRoles } = useContext(AuthContext);
    const navigate    = useNavigate();
    const dispatch    = useDispatch();
    const [sp, setSp] = useSearchParams();
    const q           = sp.get('q')    || '';
    const sort        = sp.get('sort') || '';

    const { list: products, status: prodStatus, error: prodError } = useSelector(s => s.products);
    const likes = useSelector(s => s.likes.entities);
    const { items: cart } = useSelector(s => s.cart);

    // Load products
    useEffect(() => {
        dispatch(fetchProducts({ q, sort }));
    }, [q, sort, dispatch]);

    // Load likes & cart
    useEffect(() => {
        products.forEach(p => dispatch(fetchLikes(p.id)));
    }, [products, dispatch]);
    useEffect(() => {
        dispatch(fetchCart());
    }, [dispatch]);

    const onToggleLike = id => {
        if (!userRoles.length) {
            alert(t('productsPage.loginToLike'));
            return navigate('/login');
        }
        dispatch(toggleLike(id)).unwrap().catch(err => {
            if (err.status === 401) {
                alert(t('productsPage.loginToLike'));
                navigate('/login');
            }
        });
    };

    const onAddToCart = id => {
        dispatch(addToCart(id)).unwrap().catch(() => {
            alert(t('productsPage.addToCartError'));
        });
    };

    const applyFilters = e => {
        e.preventDefault();
        const data = new FormData(e.target);
        const params = {};
        for (let [k,v] of data.entries()) if (v) params[k] = v;
        setSp(params);
    };

    if (prodStatus === 'loading') {
        return <Box textAlign="center" py={5}><CircularProgress /></Box>;
    }
    if (prodStatus === 'failed') {
        return <Typography color="error" align="center" py={5}>{prodError}</Typography>;
    }

    return (
        <Container sx={{ py: 4 }}>
            <Box mb={4} component="form" onSubmit={applyFilters} sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                <TextField name="q" defaultValue={q} label={t('productsPage.searchPlaceholder')} />
                <TextField
                    select name="sort" defaultValue={sort} label={t('productsPage.sort.none')}
                >
                    <MenuItem value="">{t('productsPage.sort.none')}</MenuItem>
                    <MenuItem value="priceAsc">{t('productsPage.sort.priceAsc')}</MenuItem>
                    <MenuItem value="priceDesc">{t('productsPage.sort.priceDesc')}</MenuItem>
                    <MenuItem value="nameAsc">{t('productsPage.sort.nameAsc')}</MenuItem>
                    <MenuItem value="nameDesc">{t('productsPage.sort.nameDesc')}</MenuItem>
                </TextField>
                <Button type="submit" variant="outlined">{t('productsPage.applyFilters')}</Button>
            </Box>

            <Grid container spacing={4}>
                {products.map(p => (
                    <Grid item xs={12} sm={6} md={4} lg={3} key={p.id}>
                        <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                            <CardMedia
                                component="img"
                                height="160"
                                image={p.imageUrl || 'https://via.placeholder.com/160'}
                                alt={p.name}
                            />
                            <CardContent sx={{ flexGrow: 1 }}>
                                <Typography variant="h6">{p.name}</Typography>
                                <Typography variant="body2" noWrap>{p.description}</Typography>
                                <Typography variant="subtitle1" mt={1}>${p.price}</Typography>
                            </CardContent>
                            <CardActions sx={{ justifyContent: 'space-between' }}>
                                <Button size="small" onClick={() => onToggleLike(p.id)}>
                                    {likes[p.id]?.liked ? '❤️' : '🤍'} {likes[p.id]?.count || 0}
                                </Button>
                                <Button size="small" onClick={() => onAddToCart(p.id)}>
                                    {t('productsPage.toCart')}
                                </Button>
                            </CardActions>
                        </Card>
                    </Grid>
                ))}
            </Grid>

            <Box mt={6}>
                <Typography variant="h5" gutterBottom>{t('productsPage.yourCart')}</Typography>
                {cart.length === 0 ? (
                    <Typography>{t('productsPage.cartEmpty')}</Typography>
                ) : (
                    <Box component="ul" sx={{ listStyle: 'none', p: 0 }}>
                        {cart.map((item, i) => (
                            <Box key={i} component="li" sx={{ display: 'flex', justifyContent: 'space-between', py: 1, borderBottom: '1px solid #ddd' }}>
                                <Typography>{item.name}</Typography>
                                <Typography>{item.quantity}</Typography>
                            </Box>
                        ))}
                    </Box>
                )}
            </Box>
        </Container>
    );
}
